/**
 * HW01_01 even or odd specifier
 * @author Nate Williams
 * @version 1.00, 03 January 2019
 */


import java.util.Scanner;
import java.util.Random;

public class HW01_01 {
	public static void main(String[] args) {
		System.out.printf("Please input a number between ten and one hundred (inclusive):\n", args);
		//inclusive: includes 10 and 100
		
		boolean check = false;
		int save = 0; //because Java is forgetful
		while (check == false) { //while loop to allow us to give the user additional chances if the first input is invalid
			Scanner input = new Scanner(System.in);
			int x = input.nextInt();
			//if x is outside the desired parameters, we ask the user for another number
			if (x < 10)
				System.out.printf("Your number was too small. Please try again:\n", args);
			else if (x > 100)
				System.out.printf("Your number was too large. Please try again:\n", args);
			else {
				check = true; //terminates loop
				save = x; //we can't let Java forget the input!
				}
		
		}
		System.out.printf("You input the number " + save + ".\n", args); //just to double-check
		for (int i = save; i>0; i--) { //we want to output however many numbers the user requested
			Random random = new Random();
			int num = random.nextInt(100)+1; //I looked this up on StackOverflow. I didn't want just any random numbers,
											 // I wanted the set to be bounded by something reasonable.
			System.out.printf(num + " is ",args);
			if(num % 2 == 1) //Determines if even or odd
				System.out.printf("odd.\n", args);
			else if (num % 2 == 0)
				System.out.printf("even.\n", args);
		}
	}
}
