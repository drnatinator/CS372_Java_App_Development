/**
 * HW01_02 area of circle
 * @author Nate Williams
 * @version 1.00, 03 January 2019
 */

import java.util.Scanner;

public class HW01_02 {
	public static void main(String[] args) {
	System.out.printf("Please input a radius for a circle: ", args);
	Scanner input = new Scanner(System.in);
	double r = input.nextDouble(); //takes in the first valid double input by user
	System.out.printf("\nThe radius of the circle you input is " + r + ";\n", args);
	double area = r * r * Math.PI; //outputs area, using the formula a = (pi) * r^2
	System.out.printf("and the area is " + area + ".", args);
	}
}
