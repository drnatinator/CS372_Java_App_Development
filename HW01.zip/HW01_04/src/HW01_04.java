/**
 * HW01_04 Body mass index
 * @author Nate Williams
 * @version 1.00, 04 January 2019
 */

import java.util.Scanner;

public class HW01_04 {
	public static void main(String[] args) {
		System.out.printf("Please input your weight, in pounds: ", args);
		
		Scanner input = new Scanner(System.in);
		double wght = input.nextDouble();			
		
		System.out.printf("\nNow please input your height, in inches: ",args);
		double hght = input.nextDouble();
		//above: user inputs. below: conversions to metric
		double mass = wght * 0.453592;
		double metHght = hght * 2.54 * .01;
		
		//System.out.printf("Your mass is " + mass + " kg, and your height is " + metHght + " meters.", args);//for debugging
		double bmi= mass / (metHght * metHght);
		System.out.printf("\nYour BMI is " + bmi + ".");
		
		//throwing away unnecessary decimals:
		bmi = bmi * 100;//so when we divide by 100 at the end, we've still got two decimal places
		int x = (int) bmi;//casting bmi as an int, which throws away all the garbage to the right of the decimal
		bmi = (double) x/100; //divides by 100, which resets the correct order of magnitude
		System.out.printf("\nIf you're a human being and hate excessive decimals in final answers, your BMI is " + bmi + ".", args);
	}
}
