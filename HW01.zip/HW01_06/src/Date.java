import java.util.Calendar;

public class Date {
	public int day;
	public int month;
	public int year;
	
	Date(){//default constructor
		this.day = -1;
		this.month = -1;
		this.year = -1;
	}
	
	void setDate(int day, int month, int year){
		if (month<13 && month > 0)//month must be between 1 and 12 (inclusive)
			this.month=month;
		else {
			this.month = -1;
		}
		//the day must be positive
		if (day < 1) {
			this.day = -1;
			}		
		//days must be within the bounds of the month that the date is in
		else if (day > 31 && (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)) {
			this.day = -1;
			}
		else if (day > 30 && (month == 4 || month == 6 || month == 9 || month == 11)) {
			this.day = -1;
		}
		else if (day > 29 && month == 2) {
			this.day = -1;
		}
		else if (day > 28 && month == 2 && ((year % 4 != 0 ) || ((year % 100 == 0) && (year % 1000 != 0)))) {
			this.day = -1;//lead years occur in years which are divisible by four, except on the centuries. Except they DO occur on millenia. So, 1900 is 
		}				  //NOT a leap year, but 2000 is. This logic appears numerous times below.
		else
			this.day = day;
		if (year >= 0)//year must be nonnegative (okay, so my system can't handle B.C. dates. sue me) :-)
			this.year = year;
		else {
			this.year = -1;
			//System.out.printf("Invalid year--must be positive\n", args);
		}
	}
	
public String getDate() {//returns a string with the date
		return ("Day: " + this.day + " \nMonth: " + this.month + "\nYear: " + this.year);
	}

public String dateToday() {//returns today's date
	return ("Today's date is: " + Calendar.getInstance().getTime());
}

public int diffDate(Date d1, Date d2) {//finds the difference (in days) between two specified dates
	int x = 0;
	boolean check = false;
	if (d1.year > d2.year) {//I expect d1 to be the earlier of the two dates. These three if-statements correct this, in case the user inputs the dates in the 
		Date d3 = d1;		//other order.
		d1 = d2;
		d2 = d3;
	}
	if (d1.year == d2.year && d1.month > d2.month) {
		Date d3 = d1;
		d1 = d2;
		d2 = d3;
	}
	if (d1.year == d2.year && d1.month == d2.month && d1.day > d2.day) {
		Date d3 = d1;
		d1 = d2;
		d2 = d3;
	}

	if (d1.year == d2.year && d1.month == d2.month)//if the two dates are in the same month, our job is simple.
		x = d2.day - d1.day;
	
	else if (d1.year == d2.year) {//if the dates are in the same year, but different months...
		if (d1.month == 1 || d1.month == 3 || d1.month == 5 || d1.month == 7 || d1.month == 8 || d1.month == 10 || d1.month == 12)//months with 31 days
			x = 31 - d1.day;//since d1 is the earlier date and d2 is in a later month, we add the remaining days in the month of d1 to x
		else if (d1.month == 4 || d1.month == 6 || d1.month == 9 || d1.month == 11)//months with 30 days
			x = 30 - d1.day;
		else if (d1.year % 4 == 0 && (d1.year % 100 != 0 || d1.year % 1000 == 0))//February is dumb.
			x = 29 - d1.day;
		else
			x = 28 - d1.day;
		x += d2.day;//since d2 is in a different month from d1, we know we need to add the number of days into the month that d2 is to our total
		if (d1.month < 2 && d2.month > 2) {//if we "skip" February, we add 28 or 29 days to our total
			if (d1.year % 4 == 0 && (d1.year % 100 != 0 || d1.year % 1000 == 0))
				x += 29;
			else
				x += 28;
		}
		if (d1.month < 3 && d2.month > 3) //same as above, but simpler for the rest of the months, because all the rest have a set number of days
			x += 31;
		if (d1.month < 4 && d2.month > 4)
			x += 30;
		if (d1.month < 5 && d2.month > 5)
			x += 31;
		if (d1.month < 6 && d2.month > 6)
			x += 30;
		if (d1.month < 7 && d2.month > 7)
			x += 31;
		if (d1.month < 8 && d2.month > 8)
			x += 31;
		if (d1.month < 9 && d2.month > 9)
			x += 30;
		if (d1.month < 10 && d2.month > 10)
			x += 31;
		if (d1.month < 11 && d2.month > 11)
			x += 30;//we don't ever "skip" January or December here, because we know that d1 and d2 are in the same year (for now).
			
	}
	else {//if the dates are in different years...
		if (d1.month == 12)
			x+=(31-d1.day);//add the rest of the days in the year of d1 to our total
		else {
			x+=31;//if d1 is not in December, we need to add all 31 days of December to the total 
			if (d1.month == 11)
				x+=(30-d1.day); //if d1 is in November, we also add the remaining days in this month to the total
			else { 
				x+=30;//otherwise, we add all the days in November to our total
				if (d1.month == 10)//and so on. It looks ugly, but it's a simply algorithm which couldn't easily be looped, since the number of days in each
					x+=(31-d1.day);//month is different and doesn't follow a simple pattern.
				else { 
					x+=31;
					if (d1.month == 9)
						x+=(30-d1.day);
					else { 
						x+=30;
						if (d1.month == 8)
							x+=(31-d1.day);
						else { 
							x+=31;
							if (d1.month == 7)
								x+=(31-d1.day);
							else {
								x += 31;
								if (d1.month == 6)
									x+=(30-d1.day);
								else {
									x += 30;
									if (d1.month == 5)
										x+=(31-d1.day);
									else {
										x += 31;
										if (d1.month == 4)
											x+=(30-d1.day);
										else {
											x += 30;
											if (d1.month == 3)
												x+=(31-d1.day);
											else {
												x += 31;
												if (d1.month == 2) {//February is dumb.
													if (d1.year % 4 == 0 && (d1.year % 100 != 0 || d1.year % 1000 == 0))
													x+=(29-d1.day);
													else
														x+=(28-d1.day);
													}
												else {
													if (d1.year % 4 == 0 && (d1.year % 100 != 0 || d1.year % 1000 == 0))
														x+=29;
													else
														x+=28;
													x += 31-d1.day;
													}}}}}}}}}}}//that's a lot of brackets, to close all the nested ifs...
		x += d2.day;//we know we need to add the number of days in d2's month that have already gone by
		if (d2.month > 1)//basically, the inverse of that mess above, but simpler in this direction. If d2 is in January, the above line handles d2's year. If not,
			x+=31;		 //we add the 31 days in January.
		if (d2.month > 2) {//If d2 is in a month after February, we add the 28 or 29 days of February.
			if (d2.year % 4 == 0 && (d2.year % 100 != 0 || d2.year % 1000 == 0))
				x+=29;
			else x+=28;
		}
		if (d2.month > 3)//and so on.
			x+= 31;
		if (d2.month > 4)
			x+=30;
		if (d2.month>5)
			x+=31;
		if (d2.month>6)
			x+=30;
		if (d2.month>7)
			x+=31;
		if (d2.month>8)
			x+=31;
		if (d2.month>9)
			x+=30;
		if (d2.month>10)
			x+=31;
		if (d2.month>11)//obviously, d2 can't be in a month after December (it'd roll over to a new year), so we stop with November.
			x+=30;
		int counter = d2.year-d1.year;//the difference between the two years. We also need to add in all the days from entire years in between d1 and d2...
		for (int i = 1; i < counter; i++) {//i starts at 1, because if d1 and d2 are in adjacent years (e.g. 2018 and 2019, we don't need to add any more days. 
			x+=365;						   //Only if the years are further apart. Then, we add the 365 days.
			if ((d1.year + i) % 4 == 0 &&((d1.year+i)%100!=0)||(d1.year+i)%1000 == 0)//plus one if it's a leap year that we're adding.
				x+=1;
		}
			

		}
	return x;//I'm sure there was a much easier way to do this, but hey, it WORKS! I tested it with numerous dates, and I'm pretty sure there isn't an error.
}
}

