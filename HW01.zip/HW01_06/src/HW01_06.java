/**
 * HW01_06 Date Class
 * @author Nate Williams
 * @version 1.00, 04 January 2019
 */
public class HW01_06 {
	public static void main(String[] args) {
		Date testDate = new Date();
		Date testDate2 = new Date();//create two Dates
		testDate.setDate(29, 3, 1998);
		testDate2.setDate(30,  11,  2117);//set them with arbitrary values. Invalid values will be set to -1 (which would, in any real database, throw a flag)
		
		System.out.printf(testDate.getDate(), args);//proves that testDate has been set in the Date class
		
		System.out.printf("\n\n" + testDate.dateToday(), args);//uses Java's built-in feature to find today's date (althought he format is different from my dates...)
		
		int diff = testDate.diffDate(testDate, testDate2);//finds the difference in days between the two test dates
		System.out.printf("\n\nThe difference between the two specified dates is " + diff + " days.", args);
	}
}
