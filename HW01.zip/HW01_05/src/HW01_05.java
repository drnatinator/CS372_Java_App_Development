/**
 * HW01_05 Employee Class
 * @author Nate Williams
 * @version 1.00, 04 January 2019
 */
public class HW01_05 {
	public static void main(String[] args) {
		Employee emp = new Employee();
		//set the values for each of the pieces of data we expect for an Employee
		emp.name = "Dwight Schrute";
		emp.position = "Assistant [to the] Regional Manager";
		emp.hireDate = "3/14/2002";
		emp.reportsTo = "Michael Scott";
		emp.ID = 123456789;
		
		
		//outputs the values associated with emp, proving that they've been set within the Employee class.
		System.out.printf("Name: " + emp.name, args);
		System.out.printf("\nPosition: " + emp.position, args);
		System.out.printf("\nHire Date: " + emp.hireDate, args);
		System.out.printf("\nReports to: " + emp.reportsTo, args);
		System.out.printf("\nID: " + emp.ID, args);
	}
}

