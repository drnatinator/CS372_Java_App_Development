
public class Employee {//simply stores the below, self-explanatory pieces of information for each Employee
	public String name;
	public int ID;
	public String hireDate;
	public String position;
	public String reportsTo;
}
