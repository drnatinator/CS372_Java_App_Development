/**
 * HW01_03 String to int
 * @author Nate Williams
 * @version 1.00, 03 January 2019
 */

import java.util.Arrays;
import java.util.Scanner;

public class HW01_03 {
	public static void main(String[] args) {
		System.out.printf("Please input a number: ");

		boolean check = false;
		while (check == false) {
			Scanner input = new Scanner(System.in);
			String str = input.nextLine(); //takes in whatever the user typed
			//System.out.printf("the number you gave me is: " + str + "\n", args); //For debugging
			byte[] test = str.getBytes();			
			if (test[0] < 48) //checks if the first character is one of the ten numerical digits
				System.out.printf("\nYou didn't do a number. Try again. ", args);
			else if (test[0] > 57)
				System.out.printf("\nYou didn't do a number. Try again. ", args);
			else {
				check = true; //terminates while-loop
				int i=0;
				int x=0;
				int y = test.length; //total length of the string (may contain non-numbers after the first digit)
				while (i < test.length) {
					int z = test[i]-48;//the -48 accounts for the ASCII code to make it the correct number
					//System.out.printf("ascii: " + test[i] + "\n", args);//for debugging; outputs ascii code of digit
					if (test[i] < 48)//if digits (after the first) are not numbers, we terminate the loop, effectively
						break;		 //throwing away what's left of the user's input.
					else if (test[i] > 57)
						break;
					else {
						
						for (int j = test.length-i-1; j>0;j--) {
							z = z * 10;//when converting to an int, we need to get the correct power of ten. This loop 
						}			   //multiplies each digit by ten x times, where x is the number of places left in the string.
						x+=z;		   //When the proper power of ten has been found, we add the digit to the output
						i++;
						y--;
					}
					
			} 
				//If the user input only numbers, y will have decremented to zero, and the next step amounts to multiplying by 1.
				//If, however, the user input non-numerical characters, y will keep track of how many chars were "thrown away."
				//We divide our answer by 10^(y), which shifts the decimal in our answer to the left, accounting for these digits.
				x = (int) (x / (java.lang.Math.pow(10,y)));
				System.out.printf ("Here's the resulting int: " + x);
		}
		}
		
	}
}
