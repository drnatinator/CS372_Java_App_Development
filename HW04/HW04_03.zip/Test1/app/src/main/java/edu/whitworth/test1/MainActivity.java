/**
 * HW04_03 Yahtzee for Android
 * @author Nate Williams
 * @version 1.00, 22 January 2019
 */

package edu.whitworth.test1;

import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    final Thread[] thds=new Thread[5];;//array of threads, one for each die
    final rollDice[] dr = new rollDice[5];//array of rollDice objects, one to be run by each thread from above
    public int chanceVal =0;//the chance score, to be output after each roll is finished
    Handler handle;//for writing to the screen in the main thread

    /**
     *
     * @param savedInstanceState Not quite sure what this parameter does--Android Studio created this function automatically
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button button = (Button) findViewById (R.id.button);//button for rolling the dice
        button.setOnClickListener(new View.OnClickListener(){//listen for button presses
            public void onClick(View v){
                Thread t = new Thread(new Runnable(){//launch a new thread
                    public void run(){
                        rollDie();//call rollDie, which sets up the five rollDice objects
                    }
                });
                t.start();//start the new thread
            }
        });

    }

    protected void rollDie(){//roll the five dice by assigning each its own thread
        ImageView imgs[]={findViewById(R.id.die1),findViewById(R.id.die2),findViewById(R.id.die3),findViewById(R.id.die4),findViewById(R.id.die5)};//print the five dice to the screen
        for(int i=0;i<5;i++){//creates the five rollDice objects, each assigned to one of the images that is printed to the screen
            ImageView l = imgs[i];
            dr[i] = new rollDice(l);
        }
        Random rnd = new Random();
            for(int i=0;i<5;i++){
                thds[i]=new Thread(dr[i]);//start the five threads for the five objects
                thds[i].start();
               try{
                   int delay = rnd.nextInt(400)+50;//delay a random amount of time, between 50 and 450 ms, between each thread
                   Thread.sleep(delay);}
               catch(InterruptedException e){;}
            }
            try{
                for(int i=0;i<5;i++)
                    thds[i].join();//wait for each of the five threads to finish rolling before proceeding
            }
            catch(InterruptedException e){;}
            chanceVal =0;//clear any previous rolls
        for (int i=0;i<5;i++) chanceVal+=dr[i].getValue();//sum the five final dice

        handle = new Handler(Looper.getMainLooper());
        handle.post(new Runnable() {
            public void run() {
                printScore();//call the below function to print the score in the bottom right corner of the screen
            }
        });
    }

    public void printScore(){//print the chance score to the screen of the phone
        TextView tv = (TextView)findViewById(R.id.total);
        tv.setText("Score "+chanceVal);
    }
}
