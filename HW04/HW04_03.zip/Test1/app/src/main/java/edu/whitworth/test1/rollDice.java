package edu.whitworth.test1;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import java.util.Random;



public class rollDice implements Runnable{
    private ImageView _label;
    private int faceValue=0,finalVal=0;
    public rollDice (ImageView label) {
        _label = label;
    }
    Handler handler;


    public void run() {//chooses which side the dice land on
        Random rnd = new Random();
        for (int i = 25; i>0; i--) {//each die will roll 25 times
            handler = new Handler(Looper.getMainLooper());//makes the main thread print the new face to the screen using dieFace
            handler.post(new Runnable() {
                public void run() {
                    dieFace();
                }
            });
            try {
                int delay = 15*((26-i))+50;//delay a variable amount, increasing each time until the die is done rolling
                Thread.sleep(delay);
            }
            catch (InterruptedException ex) {;}

        }
        finalVal = faceValue+1;
    }

    /**
     *
     * @return finalVal is the value of the final side of the die
     */
    public int getValue() {
        return finalVal;
    }

    private void dieFace(){//chooses a random side of a die and returns the associated label
        Random rnd = new Random();
        faceValue = rnd.nextInt(6);
        if (faceValue==0)
            _label.setImageResource(R.drawable.one);
        else if (faceValue==1)
            _label.setImageResource(R.drawable.two);
        else if (faceValue==2)
            _label.setImageResource(R.drawable.three);
        else if (faceValue==3)
            _label.setImageResource(R.drawable.four);
        else if (faceValue==4)
            _label.setImageResource(R.drawable.five);
        else
            _label.setImageResource(R.drawable.six);
    }
}
